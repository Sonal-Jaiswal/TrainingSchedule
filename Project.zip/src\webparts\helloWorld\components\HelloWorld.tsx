import * as React from "react";
import {
 PrimaryButton,
 DefaultButton,
 TextField,
 Dropdown,
 IDropdownOption,
 MessageBar,
 MessageBarType,
 Spinner,
 SpinnerSize
} from "@fluentui/react";
import { IHelloWorldProps } from "./IHelloWorldProps";
import { spfi, SPFI, SPFx } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";


// ============================================================
// Interfaces
// ============================================================
interface ITraining {
 Id: number;
 TrainingName: string;
 Description: string;
 Category: string;
 Trainer: string;
 TrainingDate: string;
 AvailableSeats: number;
 Status: string;
}
interface IEnrollment {
 Id: number;
 Employee: string;
 Training: string;
 EnrollDate: string;
 Status: string;
 CompletionStatus: string;
}

// ============================================================
// Main Component
// ============================================================
const HelloWorld: React.FC<IHelloWorldProps> = (props) => {
 // ----------------------------------------------------------
 // State
 // ----------------------------------------------------------
 const [sp, setSp] = React.useState<SPFI | null>(null);
 const [trainings, setTrainings] =
   React.useState<ITraining[]>([]);
 const [enrollments, setEnrollments] =
   React.useState<IEnrollment[]>([]);
 const [loading, setLoading] =
   React.useState<boolean>(true);
 const [submitting, setSubmitting] =
   React.useState<boolean>(false);
 const [error, setError] =
   React.useState<string>("");
 const [success, setSuccess] =
   React.useState<string>("");
 const [searchText, setSearchText] =
   React.useState<string>("");
 const [selectedCategory, setSelectedCategory] =
   React.useState<string>("All");
 const [selectedTraining, setSelectedTraining] =
   React.useState<ITraining | null>(null);
 const [showEnrollForm, setShowEnrollForm] =
   React.useState<boolean>(false);
 const [employeeName, setEmployeeName] =
   React.useState<string>("");

 // ==========================================================
 // INLINE STYLES
 // ==========================================================
 const styles: {
   [key: string]: React.CSSProperties
 } = {
   page: {
     fontFamily:
       '"Segoe UI", Arial, sans-serif',
     backgroundColor: "#f5f7fa",
     minHeight: "100%",
     padding: "24px",
     boxSizing: "border-box"
   },
   header: {
     background:
       "linear-gradient(135deg, #0078d4, #005a9e)",
     color: "#ffffff",
     padding: "28px 32px",
     borderRadius: "12px",
     marginBottom: "24px",
     display: "flex",
     justifyContent: "space-between",
     alignItems: "center",
     boxShadow:
       "0 4px 12px rgba(0,0,0,0.12)"
   },
   headerTitle: {
     margin: "0 0 8px 0",
     fontSize: "28px",
     fontWeight: 600
   },
   headerSubtitle: {
     margin: 0,
     fontSize: "15px",
     opacity: 0.9
   },
   userBadge: {
     backgroundColor:
       "rgba(255,255,255,0.18)",
     padding: "10px 16px",
     borderRadius: "20px",
     fontSize: "14px"
   },
   statsContainer: {
     display: "grid",
     gridTemplateColumns:
       "repeat(auto-fit, minmax(180px, 1fr))",
     gap: "16px",
     marginBottom: "28px"
   },
   statCard: {
     backgroundColor: "#ffffff",
     borderRadius: "10px",
     padding: "20px",
     boxShadow:
       "0 2px 8px rgba(0,0,0,0.08)",
     border:
       "1px solid #e5e5e5"
   },
   statNumber: {
     fontSize: "30px",
     fontWeight: 700,
     color: "#0078d4",
     marginBottom: "5px"
   },
   statLabel: {
     color: "#605e5c",
     fontSize: "14px"
   },
   section: {
     backgroundColor: "#ffffff",
     borderRadius: "12px",
     padding: "24px",
     marginBottom: "24px",
     boxShadow:
       "0 2px 8px rgba(0,0,0,0.07)"
   },
   sectionTitle: {
     margin:
       "0 0 20px 0",
     fontSize: "21px",
     color: "#323130",
     fontWeight: 600
   },
   filterContainer: {
     display: "grid",
     gridTemplateColumns:
       "2fr 1fr",
     gap: "20px",
     marginBottom: "24px"
   },
   trainingGrid: {
     display: "grid",
     gridTemplateColumns:
       "repeat(auto-fit, minmax(300px, 1fr))",
     gap: "20px"
   },
   trainingCard: {
     backgroundColor: "#ffffff",
     border:
       "1px solid #e1dfdd",
     borderRadius: "12px",
     padding: "20px",
     boxShadow:
       "0 2px 8px rgba(0,0,0,0.06)",
     transition:
       "transform 0.2s ease"
   },
   trainingHeader: {
     display: "flex",
     justifyContent: "space-between",
     alignItems: "flex-start",
     gap: "10px",
     marginBottom: "12px"
   },
   trainingTitle: {
     margin: 0,
     color: "#323130",
     fontSize: "19px",
     fontWeight: 600
   },
   activeBadge: {
     backgroundColor: "#dff6dd",
     color: "#107c10",
     padding: "5px 10px",
     borderRadius: "15px",
     fontSize: "12px",
     fontWeight: 600,
     whiteSpace: "nowrap"
   },
   inactiveBadge: {
     backgroundColor: "#fde7e9",
     color: "#a4262c",
     padding: "5px 10px",
     borderRadius: "15px",
     fontSize: "12px",
     fontWeight: 600,
     whiteSpace: "nowrap"
   },
   description: {
     color: "#605e5c",
     fontSize: "14px",
     lineHeight: "1.5",
     minHeight: "63px",
     marginBottom: "16px"
   },
   details: {
     borderTop:
       "1px solid #edebe9",
     paddingTop: "14px",
     marginBottom: "18px"
   },
   detailRow: {
     display: "flex",
     justifyContent: "space-between",
     gap: "10px",
     padding: "6px 0",
     fontSize: "13px"
   },
   detailLabel: {
     color: "#605e5c",
     fontWeight: 600
   },
   detailValue: {
     color: "#323130",
     textAlign: "right"
   },
   noResults: {
     textAlign: "center",
     padding: "50px 20px",
     color: "#605e5c"
   },
   overlay: {
     position: "fixed",
     top: 0,
     left: 0,
     right: 0,
     bottom: 0,
     backgroundColor:
       "rgba(0,0,0,0.45)",
     display: "flex",
     justifyContent: "center",
     alignItems: "center",
     zIndex: 1000
   },
   modal: {
     backgroundColor: "#ffffff",
     width: "90%",
     maxWidth: "500px",
     borderRadius: "12px",
     padding: "28px",
     boxShadow:
       "0 10px 30px rgba(0,0,0,0.25)"
   },
   modalTitle: {
     margin:
       "0 0 20px 0",
     fontSize: "23px",
     color: "#323130"
   },
   modalTraining: {
     backgroundColor: "#f3f9fd",
     borderLeft:
       "4px solid #0078d4",
     padding: "15px",
     marginBottom: "20px"
   },
   modalDetail: {
     margin:
       "8px 0",
     fontSize: "14px",
     color: "#323130"
   },
   modalButtons: {
     display: "flex",
     gap: "12px",
     marginTop: "25px"
   },
   footer: {
     textAlign: "center",
     color: "#8a8886",
     fontSize: "12px",
     marginTop: "30px"
   }
 };

 // ==========================================================
 // Initialize PnPjs
 // ==========================================================
 React.useEffect(() => {
   const spInstance =
     spfi()
       .using(
         SPFx(props.context)
       );
   setSp(spInstance);
 }, [props.context]);

 // ==========================================================
 // Load SharePoint Data
 // ==========================================================
 React.useEffect(() => {
   if (!sp) {
     return;
   }
   const loadData = async (): Promise<void> => {
     try {
       setLoading(true);
       setError("");

       // ----------------------------------------------------
       // Current User
       // ----------------------------------------------------
       const currentUser =
         await sp.web.currentUser();
       setEmployeeName(
         currentUser.Title
       );

       // ----------------------------------------------------
       // Trainings-SAR
       // ----------------------------------------------------
       const trainingItems: any[] =
         await sp.web.lists
           .getByTitle(
             "Trainings-SAR"
           )
           .items
           .select(
             "Id",
             "Title",
             "Description",
             "Category",
             "Trainer",
             "TrainingDate",
             "AvailableSeats",
             "Status"
           )
           .orderBy(
             "TrainingDate",
             true
           )();

       console.log(
         "Trainings-SAR:",
         trainingItems
       );

       const trainingData: ITraining[] =
         trainingItems.map(
           (item: any) => ({
             Id: item.Id,
             TrainingName:
               item.Title || "",
             Description:
               item.Description || "",
             Category:
               item.Category || "",
             Trainer:
               item.Trainer || "",
             TrainingDate:
               item.TrainingDate || "",
             AvailableSeats:
               Number(
                 item.AvailableSeats || 0
               ),
             Status:
               item.Status || ""
           })
         );

       setTrainings(
         trainingData
       );

       // ----------------------------------------------------
       // Enrollments-SAR
       // ----------------------------------------------------
       const enrollmentItems: any[] =
         await sp.web.lists
           .getByTitle(
             "Enrollments-SAR"
           )
           .items
           .select(
             "Id",
             "Employee/Title",
             "Training/Title",
             "EnrollDate",
             "Status",
             "CompletionStatus"
           )
           .expand(
             "Employee",
             "Training"
           )
           .orderBy(
             "Created",
             false
           )();

       console.log(
         "Enrollments-SAR:",
         enrollmentItems
       );

       const enrollmentData:
         IEnrollment[] =
         enrollmentItems.map(
           (item: any) => ({
             Id: item.Id,
             Employee:
               item.Employee?.Title ||
               "",
             Training:
               item.Training?.Title ||
               "",
             EnrollDate:
               item.EnrollDate || "",
             Status:
               item.Status || "",
             CompletionStatus:
               item.CompletionStatus || ""
           })
         );

       setEnrollments(
         enrollmentData
       );
     }
     catch (err) {
       console.error(
         "SharePoint loading error:",
         err
       );
       setError(
         "Unable to load data from SharePoint. Please verify your list names and column internal names."
       );
     }
     finally {
       setLoading(false);
     }
   };

   loadData();
 }, [sp]);

 // ==========================================================
 // Categories
 // ==========================================================
const categories: IDropdownOption[] = [
 {
   key: "All",
   text: "All Categories"
 }
];
trainings.forEach((training) => {
 if (
   training.Category &&
   categories.filter(
     category =>
       category.key === training.Category
   ).length === 0
 ) {
   categories.push({
     key: training.Category,
     text: training.Category
   });
 }
});
 // ==========================================================
 // Filter Trainings
 // ==========================================================
 const filteredTrainings =
   trainings.filter(
     training => {
       const search =
         searchText
           .toLowerCase()
           .trim();

       const matchesSearch =
         training.TrainingName
           .toLowerCase()
           .indexOf(search) ||
         training.Description
           .toLowerCase()
           .indexOf(search);

       const matchesCategory =
         selectedCategory === "All" ||
         training.Category ===
           selectedCategory;

       return (
         matchesSearch &&
         matchesCategory
       );
     }
   );

 // ==========================================================
 // Statistics
 // ==========================================================
 const totalTrainings =
   trainings.length;

 const activeTrainings =
   trainings.filter(
     training =>
       training.Status
         .toLowerCase() ===
       "active"
   ).length;

 const totalSeats =
   trainings.reduce(
     (total, training) =>
       total +
       training.AvailableSeats,
     0
   );

 const myEnrollments =
   enrollments.filter(
     enrollment =>
       enrollment.Employee ===
       employeeName
   ).length;

 // ==========================================================
 // Open Enrollment
 // ==========================================================
 const openEnrollment =
   (training: ITraining): void => {
     if (
       training.AvailableSeats <= 0
     ) {
       setError(
         "There are no available seats for this training."
       );
       return;
     }

     setSelectedTraining(
       training
     );
     setShowEnrollForm(
       true
     );
     setError("");
     setSuccess("");
   };

 // ==========================================================
 // Submit Enrollment
 // ==========================================================
//  const submitEnrollment =
//    async (): Promise<void> => {
//      if (!sp) {
//        return;
//      }

//      if (!selectedTraining) {
//        setError(
//          "Please select a training."
//        );
//        return;
//      }

//      try {
//        setSubmitting(true);
//        setError("");
//        setSuccess("");

//        // ----------------------------------------------------
//        // Current User
//        // ----------------------------------------------------
//        const currentUser =
//          await sp.web.currentUser();

//        // ----------------------------------------------------
//        // Check duplicate enrollment
//        // ----------------------------------------------------
//        const existing =
//          await sp.web.lists
//            .getByTitle(
//              "Enrollments-SAR"
//            )
//            .items
//            .select(
//              "Id",
//              "Employee/Id",
//              "Training/Id"
//            )
//            .expand(
//              "Employee",
//              "Training"
//            )
//            .filter(
//              `Employee/Id eq ${currentUser.Id} and Training/Id eq ${selectedTraining.Id}`
//            )();

//        if (
//          existing.length > 0
//        ) {
//          setError(
//            "You are already enrolled in this training."
//          );
//          return;
//        }

//        // ----------------------------------------------------
//        // CREATE NEW ENROLLMENT
//        // ----------------------------------------------------
//        const result =
//          await sp.web.lists
//            .getByTitle(
//              "Enrollments-SAR"
//            )
//            .items
//            .add({
//              Title:
//                `Enrollment - ${currentUser.Title}`,
//              EmployeeId:
//                currentUser.Id,
//              TrainingId:
//                selectedTraining.Id,
//              EnrollDate:
//                new Date().toISOString(),
//              Status:
//                "Enrolled",
//              CompletionStatus:
//                "Not Started"
//            });

//        console.log(
//          "Enrollment created successfully:",
//          result
//        );

//        // ----------------------------------------------------
//        // Success message
//        // ----------------------------------------------------
//        setSuccess(
//          `Successfully enrolled in ${selectedTraining.TrainingName}.`
//        );

//        setShowEnrollForm(
//          false
//        );
//        setSelectedTraining(
//          null
//        );

//        // ----------------------------------------------------
//        // Reload enrollment data
//        // ----------------------------------------------------
//        const enrollmentItems: any[] =
//          await sp.web.lists
//            .getByTitle(
//              "Enrollments-SAR"
//            )
//            .items
//            .select(
//              "Id",
//              "Employee/Title",
//              "Training/Title",
//              "EnrollDate",
//              "Status",
//              "CompletionStatus"
//            )
//            .expand(
//              "Employee",
//              "Training"
//            )
//            .orderBy(
//              "Created",
//              false
//            )();

//        const enrollmentData:
//          IEnrollment[] =
//          enrollmentItems.map(
//            (item: any) => ({
//              Id: item.Id,
//              Employee:
//                item.Employee?.Title ||
//                "",
//              Training:
//                item.Training?.Title ||
//                "",
//              EnrollDate:
//                item.EnrollDate || "",
//              Status:
//                item.Status || "",
//              CompletionStatus:
//                item.CompletionStatus || ""
//            })
//          );

//        setEnrollments(
//          enrollmentData
//        );

//      }
//      catch (err) {
//        console.error(
//          "Enrollment error:",
//          err
//        );
//        setError(
//          "Enrollment failed. Please check the SharePoint column internal names and permissions."
//        );
//      }
//      finally {
//        setSubmitting(false);
//      }
//    };

const submitEnrollment = async (): Promise<void> => {
  if (!sp) {
    return;
  }

  if (!selectedTraining) {
    setError("Please select a training.");
    return;
  }

  try {
    setSubmitting(true);
    setError("");
    setSuccess("");

    const currentUser = await sp.web.currentUser();

    // Check duplicate enrollment
    const existing = await sp.web.lists
      .getByTitle("Enrollments-SAR")
      .items
      .select(
        "Id",
        "Employee/Id",
        "Training/Id"
      )
      .expand(
        "Employee",
        "Training"
      )
      .filter(
        `Employee/Id eq ${currentUser.Id} and Training/Id eq ${selectedTraining.Id}`
      )();

    if (existing.length > 0) {
      setError(
        "You are already enrolled in this training."
      );
      return;
    }

    // Check latest seat count
    const trainingItem: any = await sp.web.lists
      .getByTitle("Trainings-SAR")
      .items
      .getById(selectedTraining.Id)
      .select(
        "Id",
        "Title",
        "AvailableSeats"
      )();

    if (
      !trainingItem ||
      trainingItem.AvailableSeats <= 0
    ) {
      setError(
        "No seats available for this training."
      );
      return;
    }

    // Create enrollment record
    await sp.web.lists
      .getByTitle("Enrollments-SAR")
      .items
      .add({
        Title: `Enrollment - ${currentUser.Title}`,
        EmployeeId: currentUser.Id,
        TrainingId: selectedTraining.Id,
        EnrollDate: new Date().toISOString(),
        Status: "Enrolled",
        CompletionStatus: "Not Started"
      });

    // Reduce seat count
    await sp.web.lists
      .getByTitle("Trainings-SAR")
      .items
      .getById(selectedTraining.Id)
      .update({
        AvailableSeats:
          Number(trainingItem.AvailableSeats) - 1
      });

    // Reload Trainings
    const trainingItems: any[] =
      await sp.web.lists
        .getByTitle("Trainings-SAR")
        .items
        .select(
          "Id",
          "Title",
          "Description",
          "Category",
          "Trainer",
          "TrainingDate",
          "AvailableSeats",
          "Status"
        )();

    const trainingData: ITraining[] =
      trainingItems.map(
        (item: any) => ({
          Id: item.Id,
          TrainingName:
            item.Title || "",
          Description:
            item.Description || "",
          Category:
            item.Category || "",
          Trainer:
            item.Trainer || "",
          TrainingDate:
            item.TrainingDate || "",
          AvailableSeats:
            Number(
              item.AvailableSeats || 0
            ),
          Status:
            item.Status || ""
        })
      );

    setTrainings(trainingData);

    // Reload Enrollments
    const enrollmentItems: any[] =
      await sp.web.lists
        .getByTitle("Enrollments-SAR")
        .items
        .select(
          "Id",
          "Employee/Title",
          "Training/Title",
          "EnrollDate",
          "Status",
          "CompletionStatus"
        )
        .expand(
          "Employee",
          "Training"
        )();

    const enrollmentData: IEnrollment[] =
      enrollmentItems.map(
        (item: any) => ({
          Id: item.Id,
          Employee:
            item.Employee?.Title || "",
          Training:
            item.Training?.Title || "",
          EnrollDate:
            item.EnrollDate || "",
          Status:
            item.Status || "",
          CompletionStatus:
            item.CompletionStatus || ""
        })
      );

    setEnrollments(
      enrollmentData
    );

    setSuccess(
      `Successfully enrolled in ${selectedTraining.TrainingName}`
    );

    setShowEnrollForm(false);
    setSelectedTraining(null);
  }
  catch (err: any) {
    console.error(
      "Enrollment Error:",
      err
    );

    setError(
      err?.message ||
      JSON.stringify(err)
    );
  }
  finally {
    setSubmitting(false);
  }
};

 // ==========================================================
 // Cancel
 // ==========================================================
 const cancelEnrollment =
   (): void => {
     setShowEnrollForm(
       false
     );
     setSelectedTraining(
       null
     );
     setError("");
   };

 // ==========================================================
 // Loading Screen
 // ==========================================================
 if (loading) {
   return (
<div style={styles.page}>
<div
         style={{
           backgroundColor: "#ffffff",
           padding: "50px",
           borderRadius: "12px",
           textAlign: "center"
         }}
>
<Spinner
           size={SpinnerSize.large}
           label="Loading training data from SharePoint..."
         />
</div>
</div>
   );
 }

 // ==========================================================
 // UI
 // ==========================================================
 return (
<div style={styles.page}>

     {/* ==================================================== */}
     {/* HEADER */}
     {/* ==================================================== */}
<div style={styles.header}>
<div>
<h1 style={styles.headerTitle}>
           Employee Training Dashboard
</h1>
<p style={styles.headerSubtitle}>
           Discover and enroll in internal training programs
</p>
</div>

<div style={styles.userBadge}>
         👤 {employeeName}
</div>
</div>

     {/* ==================================================== */}
     {/* ERROR */}
     {/* ==================================================== */}
     {error && (
<div
         style={{
           marginBottom: "20px"
         }}
>
<MessageBar
           messageBarType={
             MessageBarType.error
           }
           isMultiline={true}
           onDismiss={() =>
             setError("")
           }
>
           {error}
</MessageBar>
</div>
     )}

     {/* ==================================================== */}
     {/* SUCCESS */}
     {/* ==================================================== */}
     {success && (
<div
         style={{
           marginBottom: "20px"
         }}
>
<MessageBar
           messageBarType={
             MessageBarType.success
           }
           onDismiss={() =>
             setSuccess("")
           }
>
           {success}
</MessageBar>
</div>
     )}

     {/* ==================================================== */}
     {/* STATISTICS */}
     {/* ==================================================== */}
<div style={styles.statsContainer}>

<div style={styles.statCard}>
<div style={styles.statNumber}>
           {totalTrainings}
</div>
<div style={styles.statLabel}>
           Total Trainings
</div>
</div>

<div style={styles.statCard}>
<div style={styles.statNumber}>
           {activeTrainings}
</div>
<div style={styles.statLabel}>
           Active Trainings
</div>
</div>

<div style={styles.statCard}>
<div style={styles.statNumber}>
           {totalSeats}
</div>
<div style={styles.statLabel}>
           Available Seats
</div>
</div>

<div style={styles.statCard}>
<div style={styles.statNumber}>
           {myEnrollments}
</div>
<div style={styles.statLabel}>
           My Enrollments
</div>
</div>

</div>

     {/* ==================================================== */}
     {/* TRAINING SECTION */}
     {/* ==================================================== */}
<div style={styles.section}>

<h2 style={styles.sectionTitle}>
         Available Trainings
</h2>

       {/* Search + Category */}
<div style={styles.filterContainer}>
<TextField
           label="Search Training"
           placeholder="Search by training name or description"
           value={searchText}
           onChange={
             (_, value) =>
               setSearchText(
                 value || ""
               )
           }
         />

<Dropdown
           label="Category"
           selectedKey={
             selectedCategory
           }
           options={categories}
           onChange={
             (_, option) => {
               if (option) {
                 setSelectedCategory(
                   option.key as string
                 );
               }
             }
           }
         />
</div>

       {/* Training Cards */}
<div style={styles.trainingGrid}>

         {filteredTrainings.map(
           training => (
<div
               key={training.Id}
               style={styles.trainingCard}
>

               {/* Card Header */}
<div style={styles.trainingHeader}>
<h3
                   style={styles.trainingTitle}
>
                   {training.TrainingName}
</h3>

<span
                   style={
                     training.Status
                       .toLowerCase() ===
                     "active"
                       ? styles.activeBadge
                       : styles.inactiveBadge
                   }
>
                   {training.Status}
</span>
</div>

               {/* Description */}
<p
                 style={styles.description}
>
                 {training.Description}
</p>

               {/* Details */}
<div style={styles.details}>

<div
                   style={styles.detailRow}
>
<span
                     style={styles.detailLabel}
>
                     Category
</span>
<span
                     style={styles.detailValue}
>
                     {training.Category}
</span>
</div>

<div
                   style={styles.detailRow}
>
<span
                     style={styles.detailLabel}
>
                     Trainer
</span>
<span
                     style={styles.detailValue}
>
                     {training.Trainer}
</span>
</div>

<div
                   style={styles.detailRow}
>
<span
                     style={styles.detailLabel}
>
                     Training Date
</span>
<span
                     style={styles.detailValue}
>
                     {training.TrainingDate
                       ? new Date(
                           training.TrainingDate
                         ).toLocaleDateString()
                       : "Not specified"}
</span>
</div>

<div
                   style={styles.detailRow}
>
<span
                     style={styles.detailLabel}
>
                     Available Seats
</span>
<span
                     style={{
                       ...styles.detailValue,
                       fontWeight: 600
                     }}
>
                     {training.AvailableSeats}
</span>
</div>

</div>

               {/* Enroll Button */}
<PrimaryButton
                 text={
                   training.AvailableSeats > 0
                     ? "Enroll Now"
                     : "Fully Booked"
                 }
                 disabled={
                   training.AvailableSeats <= 0
                 }
                 onClick={() =>
                   openEnrollment(
                     training
                   )
                 }
                 styles={{
                   root: {
                     width: "100%",
                     borderRadius: "6px"
                   }
                 }}
               />

</div>
           )
         )}

</div>

       {/* No results */}
       {filteredTrainings.length === 0 && (
<div style={styles.noResults}>
<h3>
             No trainings found
</h3>
<p>
             Try changing your search or category.
</p>
</div>
       )}

</div>

     {/* ==================================================== */}
     {/* ENROLLMENT MODAL */}
     {/* ==================================================== */}
     {showEnrollForm &&
       selectedTraining && (
<div style={styles.overlay}>

<div style={styles.modal}>

<h2 style={styles.modalTitle}>
             Confirm Enrollment
</h2>

           {/* Training Information */}
<div
             style={styles.modalTraining}
>
<h3
               style={{
                 margin:
                   "0 0 12px 0",
                 color: "#0078d4"
               }}
>
               {selectedTraining.TrainingName}
</h3>

<p
               style={styles.modalDetail}
>
<strong>
                 Category:
</strong>{" "}
               {selectedTraining.Category}
</p>

<p
               style={styles.modalDetail}
>
<strong>
                 Trainer:
</strong>{" "}
               {selectedTraining.Trainer}
</p>

<p
               style={styles.modalDetail}
>
<strong>
                 Date:
</strong>{" "}
               {selectedTraining.TrainingDate
                 ? new Date(
                     selectedTraining.TrainingDate
                   ).toLocaleDateString()
                 : "Not specified"}
</p>

<p
               style={styles.modalDetail}
>
<strong>
                 Available Seats:
</strong>{" "}
               {selectedTraining.AvailableSeats}
</p>
</div>

           {/* Employee */}
<p
             style={styles.modalDetail}
>
<strong>
               Employee:
</strong>{" "}
             {employeeName}
</p>

<p
             style={{
               fontSize: "13px",
               color: "#605e5c"
             }}
>
             Your enrollment will be saved directly
             to the SharePoint Enrollments-SAR list.
</p>

           {/* Buttons */}
<div style={styles.modalButtons}>
<PrimaryButton
               text={
                 submitting
                   ? "Submitting..."
                   : "Confirm Enrollment"
               }
               disabled={submitting}
               onClick={
                 submitEnrollment
               }
             />

<DefaultButton
               text="Cancel"
               disabled={submitting}
               onClick={
                 cancelEnrollment
               }
             />
</div>

</div>
</div>
     )}

     {/* ==================================================== */}
     {/* FOOTER */}
     {/* ==================================================== */}
<div style={styles.footer}>
       Training data powered by SharePoint & PnPjs
</div>

</div>
 );
};

export default HelloWorld;