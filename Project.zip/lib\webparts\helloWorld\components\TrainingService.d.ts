export interface ITraining {
    Id: number;
    Title: string;
    Description: string;
    Category: string;
    Trainer: string;
    TrainingDate: string;
    AvailableSeats: number;
    Status: string;
}
export declare function getTrainings(): Promise<ITraining[]>;
//# sourceMappingURL=TrainingService.d.ts.map