import * as React from 'react';

import * as ReactDom from 'react-dom';

import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';

import HelloWorld from './components/HelloWorld';

import { IHelloWorldProps } from './components/IHelloWorldProps';

import { getSP } from './components/pnpjsConfig';

export interface IHelloWorldWebPartProps {

  description: string;

}

export default class HelloWorldWebPart

  extends BaseClientSideWebPart<IHelloWorldWebPartProps> {

  public render(): void {

    const element: React.ReactElement<IHelloWorldProps> =

      React.createElement(

        HelloWorld,

        {

          description: this.properties.description,

          context: this.context

        }

      );

    ReactDom.render(

      element,

      this.domElement

    );

  }

  protected onInit(): Promise<void> {
 getSP(this.context);
 return super.onInit();
}

}
 