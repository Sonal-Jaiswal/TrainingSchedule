import * as React from 'react';
import type { ITrainingCardProps } from './ITrainingCardProps';
declare const TrainingCard: React.FC<ITrainingCardProps>;
export default TrainingCard;
//# sourceMappingURL=TrainingCard.d.ts.map