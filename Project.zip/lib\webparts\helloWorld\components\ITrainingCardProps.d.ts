export interface ITrainingCardProps {
    title: string;
    category: string;
    description: string;
    date: string;
    seats: number;
}
//# sourceMappingURL=ITrainingCardProps.d.ts.map