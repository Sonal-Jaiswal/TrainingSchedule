import * as React from "react";
import { IHelloWorldProps } from "./IHelloWorldProps";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-users/web";
declare const HelloWorld: React.FC<IHelloWorldProps>;
export default HelloWorld;
//# sourceMappingURL=HelloWorld.d.ts.map