import { WebPartContext } from "@microsoft/sp-webpart-base";
export interface IHelloWorldProps {
    description: string;
    context: WebPartContext;
}
//# sourceMappingURL=IHelloWorldProps.d.ts.map